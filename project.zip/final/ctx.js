ctx_top.rect(10,10,110,110);
//ctx_top.fillRect(10,10,110,110)
ctx_top.rect(130,10,110,110); ctx_top.rect(250,10,110,110); ctx_top.rect(370,10,110,110); ctx_top.rect(490,10,110,110);
ctx_top.rect(610,10,110,110); ctx_top.rect(730,10,110,110); ctx_top.rect(850,10,110,110); ctx_top.rect(970,10,110,110); ctx_top.rect(1090,10,110,110);

ctx_top.rect(10,130,110,110); ctx_top.rect(130,130,110,110); ctx_top.rect(250,130,110,110); ctx_top.rect(370,130,110,110); ctx_top.rect(490,130,110,110);
ctx_top.rect(610,130,110,110); ctx_top.rect(730,130,110,110); ctx_top.rect(850,130,110,110); ctx_top.rect(970,130,110,110); ctx_top.rect(1090,130,110,110);

ctx_top.rect(10,250,110,110); ctx_top.rect(130,250,110,110); ctx_top.rect(250,250,110,110); ctx_top.rect(370,250,110,110); ctx_top.rect(490,250,110,110);
ctx_top.rect(610,250,110,110); ctx_top.rect(730,250,110,110); ctx_top.rect(850,250,110,110); ctx_top.rect(970,250,110,110); ctx_top.rect(1090,250,110,110);

ctx_top.rect(10,370,110,110); ctx_top.rect(130,370,110,110); ctx_top.rect(250,370,110,110); ctx_top.rect(370,370,110,110); ctx_top.rect(490,370,110,110);
ctx_top.rect(610,370,110,110); ctx_top.rect(730,370,110,110); ctx_top.rect(850,370,110,110); ctx_top.rect(970,370,110,110); ctx_top.rect(1090,370,110,110);

ctx_top.rect(10,490,110,110); ctx_top.rect(130,490,110,110); ctx_top.rect(250,490,110,110); ctx_top.rect(370,490,110,110); ctx_top.rect(490,490,110,110);
ctx_top.rect(610,490,110,110); ctx_top.rect(730,490,110,110); ctx_top.rect(850,490,110,110); ctx_top.rect(970,490,110,110); ctx_top.rect(1090,490,110,110);

ctx_top.rect(10,610,110,110); ctx_top.rect(130,610,110,110); ctx_top.rect(250,610,110,110); ctx_top.rect(370,610,110,110); ctx_top.rect(490,610,110,110);
ctx_top.rect(610,610,110,110); ctx_top.rect(730,610,110,110); ctx_top.rect(850,610,110,110); ctx_top.rect(970,610,110,110); ctx_top.rect(1090,610,110,110);

ctx_top.rect(10,730,110,110); ctx_top.rect(130,730,110,110); ctx_top.rect(250,730,110,110); ctx_top.rect(370,730,110,110); ctx_top.rect(490,730,110,110);
ctx_top.rect(610,730,110,110); ctx_top.rect(730,730,110,110); ctx_top.rect(850,730,110,110); ctx_top.rect(970,730,110,110); ctx_top.rect(1090,730,110,110);

ctx_top.rect(10,850,110,110); ctx_top.rect(130,850,110,110); ctx_top.rect(250,850,110,110); ctx_top.rect(370,850,110,110); ctx_top.rect(490,850,110,110);
ctx_top.rect(610,850,110,110); ctx_top.rect(730,850,110,110); ctx_top.rect(850,850,110,110); ctx_top.rect(970,850,110,110); ctx_top.rect(1090,850,110,110);

ctx_top.rect(10,970,110,110); ctx_top.rect(130,970,110,110); ctx_top.rect(250,970,110,110); ctx_top.rect(370,970,110,110); ctx_top.rect(490,970,110,110);
ctx_top.rect(610,970,110,110); ctx_top.rect(730,970,110,110); ctx_top.rect(850,970,110,110); ctx_top.rect(970,970,110,110); ctx_top.rect(1090,970,110,110);

ctx_top.rect(10,1090,110,110); ctx_top.rect(130,1090,110,110); ctx_top.rect(250,1090,110,110); ctx_top.rect(370,1090,110,110); ctx_top.rect(490,1090,110,110);
ctx_top.rect(610,1090,110,110); ctx_top.rect(730,1090,110,110); ctx_top.rect(850,1090,110,110); ctx_top.rect(970,1090,110,110); ctx_top.rect(1090,1090,110,110);

